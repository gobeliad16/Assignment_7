﻿using UnityEngine;
using System.Collections;

public class HumanMovement : MonoBehaviour {
	
	Rigidbody2D characterRigidBody;
	Transform characterTransform; 
	float			hFactor;    // used to create movement
	public float 	hScale;     // sets the speed of movement
	float			vVelocity;  // used to jump
	public float	jumpValue;  // sets the height of jump

    public Transform groundCheck;       
    public float groundCheckRadius;     
    public LayerMask whatIsGround;       
    private bool grounded;    		  // for is true WHILE on ground, false WHILE NOT on ground
    private bool canDoubleJump;       // used to allow player to jump once while in the air

	private bool facingRight = true;  // starts player facing to the right (Snake faces camera, cuz he gives no f*cks)

	Animator animator;				  // used to control animation start and stop
    


	// Use this for initialization
	void Start () {
		characterTransform = gameObject.transform;
		characterRigidBody = gameObject.GetComponent<Rigidbody2D> ();

		animator = GetComponent<Animator> (); // associate our animator variable with an Animator in Unity
	}
	
	// Update is called once per frame
	void Update () {
        // checks if player is on the ground
        grounded = Physics2D.OverlapCircle(groundCheck.position, groundCheckRadius, whatIsGround);

		// horizontal movement code
		print(Input.GetAxis ("Horizontal"));				//what is this? The world may never know
		hFactor = Input.GetAxis ("Horizontal") * hScale;

		// vertical movement code (jumping *jump-jump*)
        if (canDoubleJump)
        {
            if ( Input.GetKeyDown(KeyCode.Space) ){
                vVelocity = jumpValue;
                canDoubleJump = false;
            }
            else
            {
                vVelocity = 0;
            }
        }
        else // if not double jumping, run original code when on ground
        {
            if (Input.GetKeyDown(KeyCode.Space) && grounded)
            {
                vVelocity = jumpValue;
                canDoubleJump = true;
            }
            else
            {
                vVelocity = 0;
            }
        }


		// flip the sprite to face way its moving
		if (hFactor > 0 && !facingRight) {
			flip ();
		} else if (hFactor < 0 && facingRight) {
			flip ();
		}

		// animate when hVelocity is greater than one (when a key is pressed or held down)
		animator.SetFloat("hSpeed", Mathf.Abs(hFactor));

		// animate when jumping
		animator.SetFloat("vVelocity", characterRigidBody.velocity.y); // sends the velocity of the Y axis
		animator.SetBool ("onGround", grounded); 					   // sends a true false if the the character is on the ground or not

		// implementation of jumping and moving (this is where movement ACTUALLY occurs
		characterRigidBody.velocity = characterRigidBody.velocity + new Vector2 (0, vVelocity);                             // the jump
		characterTransform.position = new Vector2 (hFactor + characterTransform.position.x, characterTransform.position.y); // the horizontal movement
	
	}

	void flip(){
		facingRight = !facingRight; 			 // witchcraft, burn it with fire
		Vector3 theScale = transform.localScale; // does something
		theScale.x = theScale.x * -1.0f; 		 // flip the x axis of the character
		transform.localScale = theScale;		 // send this new axis to the character
	}
}
