﻿using UnityEngine;
using System.Collections;

public class StatManager : MonoBehaviour {

	// Use this for initialization
	void Start () {
	    lives = 3; // decrement after a death
	}

    static public int lives; // starts at 3 and gets decremented after each death
    static public int score; // increments after a coin pile is picked up

	// Update is called once per frame
	void Update () {
	
	}
}
