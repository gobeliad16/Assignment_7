﻿using UnityEngine;
using System.Collections;

public class Trigger : MonoBehaviour {

    AudioSource pickupAudioSource;
    public AudioClip pickupSound;

	// Use this for initialization
	void Start () {
        pickupAudioSource = GameObject.Find("pickupSound").GetComponent<AudioSource>();
	}
	
	// Update is called once per frame
	void Update () {
	
	}

    void OnTriggerEnter2D(Collider2D col)
    {
        if ( col.CompareTag("Player") )
        {
            Destroy(gameObject);
            StatManager.score++; // increment the score
            pickupAudioSource.PlayOneShot(pickupSound);
        }
    }
}
